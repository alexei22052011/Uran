You downloaded very destructive malware.
This is a dangerous malware for non-peaceful version he deletes your boot sector in your PC.
if you want run it run peaceful version she not dangerous.

Created in: C++
Creator: Alexei_Sery
Tested in: Windows XP, Windows 7 